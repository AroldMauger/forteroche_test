<h2>Edition des commentaires </h2>
<h4><?= $article->getTitle() ?></h3>
<div class="adminArticle">
    <table class="monitoring-table">
        <thead>
        <tr>
            <th>PSEUDO</th>
            <th>CONTENU</th>
            <th>ACTION</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($comments as $comment) { ?>
            <tr>
                <td><?= $comment->getPseudo() ?></td>
                <td><?= $comment->getContent() ?></td>
                <td>
                    <a href="?action=deleteComment&id=<?=$comment->getId()?>&articleId=<?=$article->getId()?>"> Supprimer</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>